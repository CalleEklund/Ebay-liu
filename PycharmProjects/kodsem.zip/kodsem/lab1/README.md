1.Vad skiljer ett ramverk (framework) från ett bibliotek (library)?

  Ramverk kontroller hur koden är uppbyggd och fungerar som ett skellett
  när man vill utöka så finns det en mall att gå efter.
  Detta medan libaries är som en samling av kod som kan underlätta för specifika
  uppgifter. Libraries kan användas inom ramverks men inte tvärtom eftersom ramverk
  ligger på en högre nivå.

2.Vilka fördelar erbjuder ramverk, och specifikt Flask, vid utveckling av server-kod jämfört med ren python?

  Det finns många resurser och tillgängliga hjälpmedel online, vi använder Flask
  för att skriva mindre kod som en annan redan har skrivit. Detta är en stor fördel
  med ramverk generellt.

3.Vad är en session i server-sammanhang? Och hur fungerar en 'session' i Flask?

  Session fungerar som cookies vilket är data som lagras hos klienten, detta gör
  det möjligt för server-siden att komma ihåg information som t.ex. inloggning och kundvagn
