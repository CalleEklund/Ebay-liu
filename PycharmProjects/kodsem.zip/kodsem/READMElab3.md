1. Vad är heroku för typ av tjänst?
    Heroku är en molntjänst där man kan skapa och lagra sin app, 
    istället för att lagra den på datorn.
    
2. Varför rekommenderas ni köra en annan typ av databas än SQLite, 
   dvs. vad finns det för fördelar med att köra PostgreSQL 
   istället för SQLite på Heroku?
    PostgreSQL har ett större bibliotek, den stödjer fler datatyper, 
    och den är säkrare. Just säkerheten är viktig eftersom vår app kommer innehålla 
    privat användarinformation. 
    
3. Att genomföra under/efter laborationen: 
   Redogör för något begrepp/problem som ni har behövt googla på under 
   arbetet med labb3 (inkludera länk(ar) till de svar som ni tyckte var 
   mest informativa).
    